import sgMail from '@sendgrid/mail';

interface EmailTemplate {
  subject: string;
  html: string;
  text: string;
}

interface NotificationEmail {
  to: string;
  template: EmailTemplate;
}

class EmailService {
  private isInitialized = false;

  constructor() {
    this.initialize();
  }

  private initialize() {
    if (process.env.SENDGRID_API_KEY) {
      sgMail.setApiKey(process.env.SENDGRID_API_KEY);
      this.isInitialized = true;
    } else {
      console.warn('SENDGRID_API_KEY not found. Email notifications will be disabled.');
    }
  }

  async sendNewAirdropNotification(subscribers: string[], airdropTitle: string, airdropId: number) {
    if (!this.isInitialized) return false;

    const template: EmailTemplate = {
      subject: `New Airdrop Alert: ${airdropTitle}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #3b82f6;">New Airdrop Available!</h2>
          <p>A new airdrop opportunity has been posted:</p>
          <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin: 0; color: #1e293b;">${airdropTitle}</h3>
          </div>
          <p>
            <a href="${process.env.FRONTEND_URL || 'http://localhost:5000'}/airdrop/${airdropId}" 
               style="background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              View Airdrop Details
            </a>
          </p>
          <p style="color: #64748b; font-size: 14px;">
            Don't miss out on this opportunity to earn crypto rewards!
          </p>
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
          <p style="color: #64748b; font-size: 12px;">
            You're receiving this email because you subscribed to our airdrop notifications.
            <br>
            <a href="${process.env.FRONTEND_URL || 'http://localhost:5000'}/unsubscribe" style="color: #64748b;">Unsubscribe</a>
          </p>
        </div>
      `,
      text: `
        New Airdrop Available!
        
        ${airdropTitle}
        
        View details: ${process.env.FRONTEND_URL || 'http://localhost:5000'}/airdrop/${airdropId}
        
        Don't miss out on this opportunity to earn crypto rewards!
        
        Unsubscribe: ${process.env.FRONTEND_URL || 'http://localhost:5000'}/unsubscribe
      `
    };

    return this.sendBulkEmail(subscribers, template);
  }

  async sendWeeklyDigest(subscribers: string[], featuredAirdrops: any[]) {
    if (!this.isInitialized) return false;

    const airdropsList = featuredAirdrops.map(airdrop => `
      <div style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin: 16px 0;">
        <h4 style="margin: 0 0 8px 0; color: #1e293b;">${airdrop.title}</h4>
        <p style="margin: 0 0 12px 0; color: #64748b; font-size: 14px;">${airdrop.description.substring(0, 150)}...</p>
        <a href="${process.env.FRONTEND_URL || 'http://localhost:5000'}/airdrop/${airdrop.id}" 
           style="color: #3b82f6; text-decoration: none; font-size: 14px;">View Details →</a>
      </div>
    `).join('');

    const template: EmailTemplate = {
      subject: 'Weekly Airdrop Digest - Don\'t Miss These Opportunities!',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #3b82f6;">Weekly Airdrop Digest</h2>
          <p>Here are the top airdrop opportunities this week:</p>
          ${airdropsList}
          <div style="text-align: center; margin: 30px 0;">
            <a href="${process.env.FRONTEND_URL || 'http://localhost:5000'}/airdrops" 
               style="background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              View All Airdrops
            </a>
          </div>
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
          <p style="color: #64748b; font-size: 12px;">
            You're receiving this weekly digest because you subscribed to our newsletter.
            <br>
            <a href="${process.env.FRONTEND_URL || 'http://localhost:5000'}/unsubscribe" style="color: #64748b;">Unsubscribe</a>
          </p>
        </div>
      `,
      text: `
        Weekly Airdrop Digest
        
        ${featuredAirdrops.map(airdrop => `${airdrop.title}\n${airdrop.description.substring(0, 150)}...\nView: ${process.env.FRONTEND_URL || 'http://localhost:5000'}/airdrop/${airdrop.id}\n`).join('\n')}
        
        View all airdrops: ${process.env.FRONTEND_URL || 'http://localhost:5000'}/airdrops
        
        Unsubscribe: ${process.env.FRONTEND_URL || 'http://localhost:5000'}/unsubscribe
      `
    };

    return this.sendBulkEmail(subscribers, template);
  }

  async sendUserMilestoneEmail(userEmail: string, milestone: string, level: number) {
    if (!this.isInitialized) return false;

    const template: EmailTemplate = {
      subject: `Congratulations! You've reached Level ${level}!`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #10b981;">Milestone Achievement!</h2>
          <div style="background: linear-gradient(135deg, #10b981, #059669); color: white; padding: 30px; border-radius: 12px; text-align: center; margin: 20px 0;">
            <h3 style="margin: 0; font-size: 24px;">🎉 Level ${level} Reached!</h3>
            <p style="margin: 10px 0 0 0; font-size: 16px; opacity: 0.9;">${milestone}</p>
          </div>
          <p>Keep up the great work exploring crypto airdrops and earning rewards!</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${process.env.FRONTEND_URL || 'http://localhost:5000'}/dashboard" 
               style="background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              View Your Dashboard
            </a>
          </div>
        </div>
      `,
      text: `
        Congratulations! You've reached Level ${level}!
        
        ${milestone}
        
        Keep up the great work exploring crypto airdrops and earning rewards!
        
        View your dashboard: ${process.env.FRONTEND_URL || 'http://localhost:5000'}/dashboard
      `
    };

    return this.sendEmail(userEmail, template);
  }

  private async sendEmail(to: string, template: EmailTemplate): Promise<boolean> {
    try {
      await sgMail.send({
        to,
        from: process.env.FROM_EMAIL || 'noreply@airdrophub.com',
        subject: template.subject,
        text: template.text,
        html: template.html,
      });
      return true;
    } catch (error) {
      console.error(`Failed to send email to ${to}:`, error);
      return false;
    }
  }

  private async sendBulkEmail(recipients: string[], template: EmailTemplate): Promise<boolean> {
    try {
      const messages = recipients.map(to => ({
        to,
        from: process.env.FROM_EMAIL || 'noreply@airdrophub.com',
        subject: template.subject,
        text: template.text,
        html: template.html,
      }));

      await sgMail.send(messages);
      return true;
    } catch (error) {
      console.error('Failed to send bulk email:', error);
      return false;
    }
  }
}

export const emailService = new EmailService();