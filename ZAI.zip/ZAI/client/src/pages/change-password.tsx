import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";
import { apiRequest } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { Loader2, Key, ArrowLeft, AlertCircle } from "lucide-react";
import { Link } from "wouter";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function ChangePassword() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  const [error, setError] = useState("");

  const passwordMutation = useMutation({
    mutationFn: async (data: typeof passwordData) => {
      if (data.newPassword !== data.confirmPassword) {
        throw new Error("New passwords do not match");
      }
      if (data.newPassword.length < 6) {
        throw new Error("Password must be at least 6 characters long");
      }
      
      await apiRequest("/api/user/password", "PUT", {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword
      });
    },
    onSuccess: () => {
      toast({
        title: "Password Updated",
        description: "Your password has been successfully changed.",
      });
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
      });
      setError("");
    },
    onError: (error: Error) => {
      setError(error.message);
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({
      ...prev,
      [name]: value
    }));
    if (error) setError("");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    passwordMutation.mutate(passwordData);
  };

  // Redirect wallet users since they don't have passwords
  if (user?.wallet_address) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
        <Helmet>
          <title>Change Password - Crypto Airdrop Hub</title>
        </Helmet>
        <div className="flex flex-col md:flex-row min-h-screen">
          <Sidebar />
          <main className="flex-1 p-4 md:p-8">
            <div className="max-w-2xl mx-auto">
              <Card className="neon-border">
                <CardHeader>
                  <CardTitle className="text-xl flex items-center">
                    <Key className="h-6 w-6 mr-2" />
                    Password Change Not Available
                  </CardTitle>
                  <CardDescription>
                    Wallet-based accounts use their connected wallet for authentication and do not require a password.
                  </CardDescription>
                </CardHeader>
                <CardFooter>
                  <Link to="/profile">
                    <Button variant="outline">
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Back to Profile
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      <Helmet>
        <title>Change Password - Crypto Airdrop Hub</title>
      </Helmet>
      <div className="flex flex-col md:flex-row min-h-screen">
        <Sidebar />
        <main className="flex-1 p-4 md:p-8">
          <div className="max-w-2xl mx-auto">
            <div className="mb-6">
              <Link to="/profile">
                <Button variant="outline" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Profile
                </Button>
              </Link>
            </div>

            <Card className="neon-border-purple relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-t from-purple-500/5 to-transparent pointer-events-none"></div>
              <CardHeader className="relative z-10">
                <CardTitle className="text-xl flex items-center">
                  <Key className="h-6 w-6 mr-2 text-purple-400" />
                  Change Password
                </CardTitle>
                <CardDescription>
                  Update your account password to keep your account secure
                </CardDescription>
              </CardHeader>
              
              <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4 relative z-10">
                  {error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center">
                      <Key className="h-4 w-4 mr-2 text-purple-400" />
                      Current Password
                    </label>
                    <Input
                      type="password"
                      name="currentPassword"
                      value={passwordData.currentPassword}
                      onChange={handleInputChange}
                      disabled={passwordMutation.isPending}
                      required
                      className="neon-border-purple"
                      placeholder="Enter your current password"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center">
                      <Key className="h-4 w-4 mr-2 text-purple-400" />
                      New Password
                    </label>
                    <Input
                      type="password"
                      name="newPassword"
                      value={passwordData.newPassword}
                      onChange={handleInputChange}
                      disabled={passwordMutation.isPending}
                      required
                      className="neon-border-purple"
                      placeholder="Enter your new password (min 6 characters)"
                      minLength={6}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center">
                      <Key className="h-4 w-4 mr-2 text-purple-400" />
                      Confirm New Password
                    </label>
                    <Input
                      type="password"
                      name="confirmPassword"
                      value={passwordData.confirmPassword}
                      onChange={handleInputChange}
                      disabled={passwordMutation.isPending}
                      required
                      className="neon-border-purple"
                      placeholder="Confirm your new password"
                    />
                  </div>
                </CardContent>
                
                <CardFooter className="relative z-10">
                  <Button 
                    type="submit"
                    disabled={passwordMutation.isPending}
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    {passwordMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Updating Password...
                      </>
                    ) : (
                      <>
                        <Key className="mr-2 h-4 w-4" />
                        Update Password
                      </>
                    )}
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}