import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Megaphone, ArrowLeft } from "lucide-react";
import Header from "@/components/layout/header";
import { Helmet } from "react-helmet";

export default function PostBanner() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  // Only admins can access this page
  if (!user?.isAdmin) {
    setLocation("/");
    return null;
  }

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    link: "",
    tags: ["banner", "announcement"],
    category_id: 1, // Use Node category (ID 1)
    post_type: "announcement",
    is_banner: true, // Always true for banner posts
    status: "active",
    potential_profit: "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const createBannerMutation = useMutation({
    mutationFn: async (data: any) => {
      // Create the banner data with proper structure
      const bannerData = {
        title: data.title,
        description: data.description,
        link: data.link || "",
        tags: data.tags || ["banner", "announcement"],
        category_id: data.category_id || 1,
        post_type: "announcement",
        is_banner: true,
        status: "active",
        potential_profit: "",
      };

      const response = await fetch("/api/airdrops", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(bannerData),
        credentials: "include",
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create banner");
      }

      return response.json();
    },
    onSuccess: () => {
      // Invalidate banner and announcements queries
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops/banner"] });
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops/announcements"] });
      
      // Navigate back to announcements page
      setLocation("/announcements");
    },
    onError: (error: Error) => {
      setErrors({ submit: error.message });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      createBannerMutation.mutate(formData);
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title?.trim()) {
      newErrors.title = "Title is required";
    }
    
    if (!formData.description?.trim()) {
      newErrors.description = "Description is required";
    }
    
    if (formData.link && !isValidUrl(formData.link)) {
      newErrors.link = "Please enter a valid URL";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const isValidUrl = (string: string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };

  return (
    <>
      <Helmet>
        <title>Post Banner Announcement - Crypto Airdrop Tasks</title>
        <meta name="description" content="Create a banner announcement that will appear prominently at the top of the website" />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
        <Header />
        <main className="pt-20 pb-12">
          <div className="max-w-4xl mx-auto p-6">
            <div className="mb-6">
              <Button 
                variant="outline" 
                onClick={() => setLocation("/announcements")}
                className="mb-4"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Announcements
              </Button>
              <h1 className="text-3xl font-bold text-white mb-2">Post Banner Announcement</h1>
              <p className="text-gray-300">Create a banner that will appear prominently at the top of the website</p>
            </div>

            <Card className="bg-gray-800 border-orange-600/20">
              <CardHeader className="bg-gradient-to-r from-orange-600/10 to-red-600/10 border-b border-orange-600/20">
                <CardTitle className="text-orange-400 flex items-center">
                  <Megaphone className="mr-2 h-5 w-5" />
                  Banner Announcement
                </CardTitle>
              </CardHeader>
              
              <form onSubmit={handleSubmit}>
                <CardContent className="space-y-6 p-6">
                  {errors.submit && (
                    <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
                      <p className="text-red-400 text-sm">{errors.submit}</p>
                    </div>
                  )}

                  {/* Title */}
                  <div>
                    <Label htmlFor="title" className="text-base font-medium text-white">Banner Title *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="e.g., 🚀 New Airdrop Campaign Live!"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                    {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title}</p>}
                  </div>

                  {/* Description */}
                  <div>
                    <Label htmlFor="description" className="text-base font-medium text-white">Banner Message *</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Brief message for the banner (keep it short and engaging)"
                      rows={3}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                    {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
                  </div>

                  {/* Link */}
                  <div>
                    <Label htmlFor="link" className="text-base font-medium text-white">Related Link (Optional)</Label>
                    <Input
                      id="link"
                      type="url"
                      value={formData.link || ""}
                      onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                      placeholder="https://example.com"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                    {errors.link && <p className="text-red-500 text-sm mt-1">{errors.link}</p>}
                    <p className="text-sm text-gray-400 mt-1">Optional link for users to click from the banner</p>
                  </div>

                  <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-4">
                    <div className="flex items-center space-x-2 text-orange-400">
                      <Megaphone className="h-4 w-4" />
                      <span className="font-medium">Banner Settings</span>
                    </div>
                    <p className="text-sm text-orange-300 mt-2">
                      This announcement will automatically appear as a banner at the top of the website and rotate with other banner announcements.
                    </p>
                  </div>
                </CardContent>
                
                <CardFooter className="flex justify-between bg-gray-750 border-t border-gray-700">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setLocation("/announcements")}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createBannerMutation.isPending}
                    className="bg-orange-600 hover:bg-orange-700 text-white"
                  >
                    {createBannerMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Publishing Banner...
                      </>
                    ) : (
                      <>
                        <Megaphone className="mr-2 h-4 w-4" />
                        Publish Banner
                      </>
                    )}
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </div>
        </main>
      </div>
    </>
  );
}