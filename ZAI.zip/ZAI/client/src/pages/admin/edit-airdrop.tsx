import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { Airdrops, InsertAirdrops } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

export default function EditAirdrop() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState<Partial<InsertAirdrops>>({
    title: "",
    description: "",
    tags: [],
    link: "",
    status: "active",
  });
  
  const [currentTag, setCurrentTag] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const { data: airdrop, isLoading, error } = useQuery<Airdrops>({
    queryKey: [`/api/airdrops/${id}`],
  });
  
  // Populate form with existing data when available
  useEffect(() => {
    if (airdrop) {
      setFormData({
        title: airdrop.title,
        description: airdrop.description,
        tags: airdrop.tags || [],
        link: airdrop.link || "",
        status: airdrop.status || "active",
      });
    }
  }, [airdrop]);
  
  const updateAirdropMutation = useMutation({
    mutationFn: async (data: Partial<InsertAirdrops>) => {
      const res = await apiRequest("PUT", `/api/admin/airdrops/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/airdrops/${id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/airdrops"] });
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops"] });
      toast({
        title: "Airdrop updated",
        description: "Your airdrop tutorial has been successfully updated.",
      });
      navigate("/admin/dashboard");
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating airdrop",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title?.trim()) {
      newErrors.title = "Title is required";
    }
    
    if (!formData.description?.trim()) {
      newErrors.description = "Description is required";
    }
    
    if (!formData.tags || formData.tags.length === 0) {
      newErrors.tags = "At least one tag is required";
    }
    
    if (formData.link && !/^https?:\/\/.+/.test(formData.link)) {
      newErrors.link = "Please enter a valid URL starting with http:// or https://";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleAddTag = () => {
    if (currentTag.trim() && !formData.tags?.includes(currentTag.trim())) {
      setFormData({
        ...formData,
        tags: [...(formData.tags || []), currentTag.trim()],
      });
      setCurrentTag("");
    }
  };
  
  const handleRemoveTag = (tag: string) => {
    setFormData({
      ...formData,
      tags: formData.tags?.filter(t => t !== tag) || [],
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    updateAirdropMutation.mutate({
      ...formData,
      updated_at: new Date().toISOString(),
    });
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row">
        <Sidebar />
        <main className="flex-1 p-6 md:p-10 flex justify-center items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </main>
      </div>
    );
  }
  
  if (error || !airdrop) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row">
        <Sidebar />
        <main className="flex-1 p-6 md:p-10">
          <div className="max-w-3xl mx-auto">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-destructive mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  <h2 className="text-xl font-bold text-white mb-2">Airdrop not found</h2>
                  <p className="text-gray-400 mb-4">The airdrop you're trying to edit doesn't exist or has been removed.</p>
                  <Button 
                    variant="default" 
                    onClick={() => navigate("/admin/dashboard")}
                  >
                    Go back to dashboard
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Helmet>
        <title>Edit Airdrop - Admin Dashboard</title>
        <meta name="description" content="Edit existing airdrop tutorial or task." />
      </Helmet>
      
      <Sidebar />
      
      <main className="flex-1 p-6 md:p-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate("/admin/dashboard")}
              className="mb-4"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Back to Dashboard
            </Button>
            
            <h1 className="text-3xl font-bold text-white">Edit Airdrop</h1>
            <p className="text-gray-400 mt-2">
              Update details for "{airdrop.title}"
            </p>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Airdrop Details</CardTitle>
              <CardDescription>Edit the details for this airdrop tutorial</CardDescription>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input 
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="e.g., ZetaChain Testnet Airdrop"
                  />
                  {errors.title && (
                    <p className="text-destructive text-sm">{errors.title}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description (Tutorial Steps)</Label>
                  <Textarea 
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Provide detailed steps for completing this airdrop task..."
                    className="min-h-[200px]"
                  />
                  <p className="text-muted-foreground text-sm">
                    You can use HTML formatting for better readability.
                  </p>
                  {errors.description && (
                    <p className="text-destructive text-sm">{errors.description}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label>Tags</Label>
                  <div className="flex space-x-2">
                    <Input 
                      value={currentTag}
                      onChange={(e) => setCurrentTag(e.target.value)}
                      placeholder="Add a tag"
                      className="flex-1"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddTag();
                        }
                      }}
                    />
                    <Button 
                      type="button" 
                      variant="secondary"
                      onClick={handleAddTag}
                    >
                      Add Tag
                    </Button>
                  </div>
                  {errors.tags && (
                    <p className="text-destructive text-sm">{errors.tags}</p>
                  )}
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.tags?.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="gap-1">
                        {tag}
                        <button 
                          type="button" 
                          className="ml-1 hover:text-destructive focus:outline-none"
                          onClick={() => handleRemoveTag(tag)}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                          <span className="sr-only">Remove tag</span>
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="link">External Link (Optional)</Label>
                  <Input 
                    id="link"
                    value={formData.link}
                    onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                    placeholder="https://example.com/airdrop"
                  />
                  {errors.link && (
                    <p className="text-destructive text-sm">{errors.link}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Stats</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-md bg-background">
                      <div className="text-muted-foreground text-sm">Views</div>
                      <div className="text-2xl font-bold">{airdrop.views}</div>
                    </div>
                    <div className="p-4 rounded-md bg-background">
                      <div className="text-muted-foreground text-sm">Created</div>
                      <div className="text-sm font-medium">{new Date(airdrop.created_at).toLocaleDateString()}</div>
                    </div>
                  </div>
                </div>
                
                {updateAirdropMutation.error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      {updateAirdropMutation.error.message}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => navigate("/admin/dashboard")}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={updateAirdropMutation.isPending}
                >
                  {updateAirdropMutation.isPending ? "Updating..." : "Update Airdrop"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>
    </div>
  );
}
