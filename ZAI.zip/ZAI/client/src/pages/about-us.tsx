import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Helmet } from "react-helmet";
import LegalHeader from "@/components/layout/legal-header";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

export default function AboutUs() {
  const teamMembers = [
    {
      name: "Development Team",
      role: "Platform Development",
      description: "Full-stack developers specializing in blockchain technology and Web3 integration.",
      badge: "TEAM"
    },
    {
      name: "Community Moderators",
      role: "Community Management",
      description: "Dedicated moderators ensuring a safe and productive environment for all users.",
      badge: "ADMIN"
    },
    {
      name: "Security Auditors",
      role: "Platform Security",
      description: "Security experts continuously monitoring and improving platform safety measures.",
      badge: "SECURITY"
    }
  ];

  const features = [
    {
      title: "Curated Airdrop Listings",
      description: "Hand-picked airdrops from legitimate projects with detailed information and requirements."
    },
    {
      title: "Web3 Wallet Integration",
      description: "Secure authentication using Sign-In with Ethereum (SIWE) and support for major wallets."
    },
    {
      title: "Real-time Community Chat",
      description: "Live chat functionality for community discussions and real-time updates."
    },
    {
      title: "Creator Program",
      description: "Verified creators can submit and manage airdrop listings with proper oversight."
    },
    {
      title: "Advanced Filtering",
      description: "Filter airdrops by category, status, requirements, and potential rewards."
    },
    {
      title: "Security First",
      description: "Built with security best practices, encrypted sessions, and secure data handling."
    }
  ];

  return (
    <>
      <Helmet>
        <title>About Us | AirdropVerse</title>
        <meta name="description" content="Learn about AirdropVerse, our mission to provide a secure platform for discovering cryptocurrency airdrops, and our commitment to the community." />
      </Helmet>
      
      <LegalHeader />
      
      <div className="container py-10 max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            About AirdropVerse
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Your trusted platform for discovering, learning about, and participating in cryptocurrency airdrops
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2 mb-12">
          <Card className="border-gray-800 shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-blue-400">Our Mission</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 leading-relaxed">
                AirdropVerse was created to bridge the gap between cryptocurrency projects and potential users 
                through legitimate airdrop opportunities. We believe in democratizing access to the growing 
                cryptocurrency ecosystem while maintaining the highest standards of security and transparency.
              </p>
              <p className="text-gray-300 leading-relaxed mt-4">
                Our platform serves as a trusted intermediary, carefully curating airdrop opportunities 
                and providing users with the information they need to make informed decisions about participation.
              </p>
            </CardContent>
          </Card>

          <Card className="border-gray-800 shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-purple-400">Our Vision</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 leading-relaxed">
                We envision a future where anyone can safely explore and benefit from the cryptocurrency 
                ecosystem through educational content, community support, and access to legitimate opportunities.
              </p>
              <p className="text-gray-300 leading-relaxed mt-4">
                By fostering a community-driven approach to airdrop discovery and education, we aim to 
                reduce barriers to entry and promote responsible participation in the decentralized economy.
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="border-gray-800 shadow-lg mb-12">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Platform Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-4 rounded-lg border border-gray-700 bg-gray-800/50"
                >
                  <h3 className="font-semibold text-white mb-2">{feature.title}</h3>
                  <p className="text-gray-300 text-sm">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-gray-800 shadow-lg mb-12">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Our Team</CardTitle>
            <p className="text-gray-400">Meet the people behind AirdropVerse</p>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-3">
              {teamMembers.map((member, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.2 }}
                  className="text-center p-6 rounded-lg border border-gray-700 bg-gray-800/50"
                >
                  <div className="mb-4">
                    <Badge className={`
                      ${member.badge === 'ADMIN' ? 'bg-red-600 hover:bg-red-700' : 
                        member.badge === 'SECURITY' ? 'bg-green-600 hover:bg-green-700' : 
                        'bg-blue-600 hover:bg-blue-700'}
                    `}>
                      {member.badge}
                    </Badge>
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-1">{member.name}</h3>
                  <p className="text-blue-400 text-sm mb-3">{member.role}</p>
                  <p className="text-gray-300 text-sm">{member.description}</p>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-gray-800 shadow-lg mb-12">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Technology Stack</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <h3 className="font-semibold text-white mb-3">Frontend Technologies</h3>
                <ul className="space-y-2 text-gray-300">
                  <li>• React 18 with TypeScript for type safety</li>
                  <li>• Tailwind CSS with shadcn/ui components</li>
                  <li>• TanStack Query for state management</li>
                  <li>• Framer Motion for animations</li>
                  <li>• Vite for fast development builds</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-white mb-3">Backend Technologies</h3>
                <ul className="space-y-2 text-gray-300">
                  <li>• Node.js with Express.js framework</li>
                  <li>• PostgreSQL with Drizzle ORM</li>
                  <li>• WebSocket for real-time communication</li>
                  <li>• Passport.js with Web3 authentication</li>
                  <li>• bcrypt for secure password hashing</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-gray-800 shadow-lg mb-12">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Security & Trust</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 rounded-lg border border-green-700/30 bg-green-900/20">
                <h3 className="font-semibold text-green-400 mb-2">Security Measures</h3>
                <ul className="text-gray-300 space-y-1">
                  <li>• HTTPS encryption for all data transmission</li>
                  <li>• Secure session management with PostgreSQL store</li>
                  <li>• Input validation and sanitization</li>
                  <li>• Regular security audits and updates</li>
                </ul>
              </div>
              <div className="p-4 rounded-lg border border-blue-700/30 bg-blue-900/20">
                <h3 className="font-semibold text-blue-400 mb-2">Privacy Protection</h3>
                <ul className="text-gray-300 space-y-1">
                  <li>• GDPR and CCPA compliant data handling</li>
                  <li>• No private key storage or requests</li>
                  <li>• Transparent data collection practices</li>
                  <li>• User control over personal information</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-gray-800 shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Contact Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="font-semibold text-white mb-3">General Inquiries</h3>
                <div className="space-y-2 text-gray-300">
                  <p>Email: contact@airdropverse.com</p>
                  <p>Support: support@airdropverse.com</p>
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-white mb-3">Legal & Compliance</h3>
                <div className="space-y-2 text-gray-300">
                  <p>Legal: legal@airdropverse.com</p>
                  <p>Privacy: privacy@airdropverse.com</p>
                </div>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-gradient-to-br from-blue-900/20 to-purple-900/20 border border-blue-800/30 rounded-lg">
              <h3 className="text-lg font-semibold text-white mb-2">Join Our Community</h3>
              <p className="text-gray-300 mb-3">
                Connect with us and stay updated on the latest airdrop opportunities and platform updates.
              </p>
              <div className="flex space-x-3">
                <a href="#" className="text-blue-400 hover:text-blue-300 transition-colors">Twitter</a>
                <a href="#" className="text-blue-400 hover:text-blue-300 transition-colors">Discord</a>
                <a href="#" className="text-blue-400 hover:text-blue-300 transition-colors">Telegram</a>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}