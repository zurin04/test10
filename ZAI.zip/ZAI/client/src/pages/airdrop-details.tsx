import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation, Link } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import Footer from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Airdrops } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Edit, Trash2 } from "lucide-react";
import { useProcessedContent } from "@/utils/code-block-processor";

export default function AirdropDetails() {
  const { id } = useParams();
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const { data: airdrop, isLoading, error } = useQuery<Airdrops>({
    queryKey: [`/api/airdrops/${id}`],
  });
  
  const saveTaskMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/airdrops/${id}/save`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/airdrops/${id}`] });
      toast({
        title: "Task saved",
        description: "This task has been added to your saved list.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save task",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const markCompleteMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/airdrops/${id}/complete`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/airdrops/${id}`] });
      toast({
        title: "Task completed!",
        description: "Great job! You've marked this task as complete.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to mark as complete",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const deleteAirdropMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", `/api/airdrops/${id}`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops"] });
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops/featured"] });
      toast({
        title: "Airdrop deleted",
        description: "Your airdrop has been successfully deleted.",
      });
      navigate("/airdrops");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete airdrop",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Check if user can edit/delete this airdrop
  const canEditDelete = user && (user.isAdmin || airdrop?.posted_by === user.username);
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row">
        <Sidebar />
        <main className="flex-1 p-6 md:p-10 flex justify-center items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </main>
      </div>
    );
  }
  
  if (error || !airdrop) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row">
        <Sidebar />
        <main className="flex-1 p-6 md:p-10">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-8">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-destructive mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                <h2 className="text-xl font-bold text-white mb-2">Airdrop not found</h2>
                <p className="text-gray-400 mb-4">The airdrop you're looking for doesn't exist or has been removed.</p>
                <Button 
                  variant="default" 
                  onClick={() => navigate("/airdrops")}
                >
                  Go back to all airdrops
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }
  
  // Check if user has saved or completed this airdrop
  const airdropId = id ? parseInt(id) : 0;
  const isSaved = user?.saved_tasks?.includes(airdropId);
  const isCompleted = user?.completed_tasks?.includes(airdropId);

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Helmet>
        <title>{airdrop.title} - Crypto Airdrop Task Hub</title>
        <meta name="description" content={`Complete the ${airdrop.title} airdrop tutorial tasks and qualify for token rewards. Follow our step-by-step guide.`} />
      </Helmet>
      
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <div className="hero-bg p-6 md:p-10">
          <div className="max-w-5xl mx-auto">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate("/airdrops")}
              className="mb-4"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Back to Airdrops
            </Button>
            
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-blue-900 rounded-full flex items-center justify-center mr-4">
                <span className="font-bold text-blue-300">{airdrop.title.charAt(0)}</span>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">{airdrop.title}</h1>
                <div className="flex items-center mt-2 space-x-2">
                  {airdrop.tags?.map((tag, index) => (
                    <Badge key={index} variant="secondary">{tag}</Badge>
                  ))}
                  <span className="text-sm text-gray-400">
                    Posted {new Date(airdrop.created_at).toLocaleDateString()}
                  </span>
                </div>
                {airdrop.posted_by && (
                  <div className="flex items-center mt-2 text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    <span>Created by </span>
                    <Link to={`/creator-timeline/${airdrop.posted_by}`} className="font-medium text-blue-400 hover:text-blue-300 hover:underline transition-colors ml-1">
                      {airdrop.posted_by}
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-6 md:p-10">
          <div className="max-w-5xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {airdrop.post_type === 'announcement' ? 'Announcement Content' :
                       airdrop.post_type === 'upcoming' ? 'Event Information' :
                       'Tutorial Steps'}
                    </CardTitle>
                    <CardDescription>
                      {airdrop.post_type === 'announcement' ? 'Read the latest updates and announcements' :
                       airdrop.post_type === 'upcoming' ? 'Details about the upcoming event' :
                       'Follow these steps to complete the airdrop tasks'}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {/* Display image for all post types */}
                    {airdrop.image_url && (
                      <div className="mb-6">
                        <img 
                          src={airdrop.image_url} 
                          alt={airdrop.post_type === 'announcement' ? 'Announcement image' : 
                               airdrop.post_type === 'upcoming' ? 'Event image' : 
                               'Featured image'}
                          className="w-full max-w-2xl mx-auto rounded-lg border border-border/60 shadow-lg"
                        />
                      </div>
                    )}
                    
                    <div 
                      className="prose prose-invert max-w-none prose-headings:text-primary prose-p:text-foreground/90 prose-img:rounded-lg prose-img:border prose-img:border-border/60" 
                      dangerouslySetInnerHTML={{ __html: useProcessedContent(airdrop.description) }} 
                    />
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {airdrop.post_type === 'announcement' ? 'Post Actions' :
                       airdrop.post_type === 'upcoming' ? 'Event Actions' :
                       'Task Actions'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                      </svg>
                      <span className="text-muted-foreground">{airdrop.views} views</span>
                    </div>
                    
                    {airdrop.link && (
                      <a 
                        href={airdrop.link} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="block w-full"
                      >
                        <Button className="w-full">
                          Visit Airdrop Site
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                          </svg>
                        </Button>
                      </a>
                    )}
                    
                    {user ? (
                      <>
                        <Button 
                          variant={isSaved ? "outline" : "secondary"} 
                          className="w-full" 
                          onClick={() => saveTaskMutation.mutate()}
                          disabled={saveTaskMutation.isPending}
                        >
                          {isSaved ? (
                            <>
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="currentColor" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                              Saved
                            </>
                          ) : (
                            <>
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                              </svg>
                              Save for Later
                            </>
                          )}
                        </Button>
                        
                        <Button 
                          variant={isCompleted ? "outline" : "default"} 
                          className="w-full" 
                          onClick={() => markCompleteMutation.mutate()}
                          disabled={markCompleteMutation.isPending}
                        >
                          {isCompleted ? (
                            <>
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="currentColor" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                              </svg>
                              {airdrop.post_type === 'announcement' ? 'Read' :
                               airdrop.post_type === 'upcoming' ? 'Interested' :
                               'Completed'}
                            </>
                          ) : (
                            <>
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                              </svg>
                              {airdrop.post_type === 'announcement' ? 'Mark as Read' :
                               airdrop.post_type === 'upcoming' ? 'Mark as Interested' :
                               'Mark as Complete'}
                            </>
                          )}
                        </Button>
                        
                        {/* Edit and Delete buttons for creators/admins */}
                        {canEditDelete && (
                          <>
                            <Button 
                              variant="outline" 
                              className="w-full" 
                              onClick={() => navigate(`/airdrops/edit/${id}`)}
                            >
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Airdrop
                            </Button>
                            
                            <Button 
                              variant="destructive" 
                              className="w-full" 
                              onClick={() => {
                                if (window.confirm("Are you sure you want to delete this airdrop? This action cannot be undone.")) {
                                  deleteAirdropMutation.mutate();
                                }
                              }}
                              disabled={deleteAirdropMutation.isPending}
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              {deleteAirdropMutation.isPending ? "Deleting..." : "Delete Airdrop"}
                            </Button>
                          </>
                        )}
                      </>
                    ) : (
                      <Button 
                        variant="outline" 
                        className="w-full" 
                        onClick={() => navigate("/auth")}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                        </svg>
                        Login to Track Progress
                      </Button>
                    )}
                  </CardContent>
                </Card>
                
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Share This Airdrop</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex space-x-4 justify-center">
                      <Button variant="outline" size="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[#1DA1F2]" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M23.954 4.569a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723 10.038 10.038 0 01-3.127 1.195 4.92 4.92 0 00-8.384 4.482 13.98 13.98 0 01-10.15-5.147 4.913 4.913 0 001.523 6.574 4.868 4.868 0 01-2.23-.616v.061a4.917 4.917 0 003.946 4.825 4.97 4.97 0 01-2.224.085 4.929 4.929 0 004.595 3.422A9.87 9.87 0 010 19.54a13.94 13.94 0 007.548 2.212c9.057 0 14.01-7.502 14.01-14.01 0-.214-.005-.425-.015-.636a10.02 10.02 0 002.46-2.548l-.047-.02z"/>
                        </svg>
                        <span className="sr-only">Share on Twitter</span>
                      </Button>
                      <Button variant="outline" size="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[#0088cc]" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14.127.106.175.27.175.27s.043.834.043 1.666l-.001 1.563-.035 1.896c0 .225-.016.458-.087.66-.123.35-.37.572-.75.647-.245.048-.493.051-.739.025-.345-.037-.661-.116-1.065-.241-.212-.066-.396-.12-.586-.19l-.393-.144c-.41-.153-.785-.328-1.153-.531-.529-.289-1.033-.642-1.513-1.037-.516-.426-1-.91-1.478-1.412-.261-.275-.509-.572-.748-.869a17.41 17.41 0 0 1-.668-.926c-.525-.79-.997-1.62-1.374-2.493-.274-.637-.487-1.302-.62-1.988-.05-.26-.087-.527-.117-.794-.026-.243-.04-.487-.054-.73-.01-.177-.016-.354-.023-.532a25.4 25.4 0 0 1-.008-.538c.006-.172.006-.345.009-.517.006-.188.025-.375.036-.562.023-.364.053-.727.097-1.087.145-1.187.473-2.348.934-3.451.047-.112.099-.222.152-.333.096-.201.196-.4.3-.597.022-.041.046-.082.07-.123.101-.174.215-.339.316-.515.168-.293.35-.577.513-.878.044-.081.084-.166.133-.245.16-.265.32-.529.488-.786.128-.195.268-.385.405-.575.116-.157.236-.312.355-.466.112-.144.223-.288.34-.427.126-.148.258-.29.387-.434.088-.097.175-.194.265-.289.061-.064.128-.121.191-.184l.019-.016c.04-.037.088-.065.145-.082.063-.019.133-.02.195.005.129.053.235.168.277.3.042.134.03.278-.032.401a.838.838 0 0 1-.234.284v.001l.002.001-.007.004-.021.014-.214.152c-.274.195-.53.415-.78.643-.222.204-.428.424-.633.646-.155.167-.311.335-.463.505-.076.085-.151.171-.224.259-.09.107-.178.217-.265.327-.206.262-.405.53-.597.803-.083.118-.164.238-.245.358-.108.162-.21.33-.317.495-.15.227-.293.458-.435.69-.055.09-.113.177-.167.267-.153.254-.3.513-.443.772-.107.195-.213.39-.314.59-.074.147-.142.297-.213.445-.226.485-.436.977-.63 1.476-.063.16-.128.318-.186.48-.114.317-.217.64-.312.965a12.883 12.883 0 0 0-.281 1.128c-.047.227-.085.457-.123.686-.041.248-.085.495-.107.745-.026.3-.035.602-.036.905 0 .165.005.328.011.492.006.211.022.422.044.632.017.146.03.293.055.439.027.159.063.314.096.471.035.162.07.325.113.486.133.493.32.97.559 1.428.111.212.232.419.363.618.06.091.122.181.185.27.126.178.262.348.397.52l.138.164c.173.2.345.402.527.596.18.193.366.381.556.565.216.208.44.407.671.598.183.151.365.303.555.447.138.105.283.2.427.298.087.059.176.114.265.17.192.118.388.227.586.334.149.08.3.156.45.231.128.065.256.13.386.191l.106.05c.212.099.426.192.641.28.154.062.309.122.466.179.183.066.369.126.554.188.226.076.454.137.683.202.089.025.177.05.266.072.223.058.449.112.675.156.336.067.673.114 1.013.159l.14.018c.277.031.555.05.833.062.166.007.332.012.499.012l.024-.001h1.184l.25-.001c.083-.3.166-.007.248-.012.195-.012.39-.032.585-.055.173-.02.347-.04.52-.07.33-.057.654-.14.975-.238.294-.09.583-.2.867-.32.075-.032.148-.069.221-.104.193-.095.388-.186.575-.29.165-.092.324-.19.482-.293.109-.07.22-.138.326-.212.16-.11.313-.227.465-.345.266-.207.523-.427.77-.654.047-.43.096-.83.142-.127.096-.09.189-.183.281-.276.165-.166.326-.334.482-.507.08-.087.153-.18.231-.269.135-.157.269-.316.397-.479.106-.135.21-.272.31-.411.044-.6.085-.124.128-.185.227-.325.442-.658.647-.999.117-.195.228-.393.335-.594.098-.183.196-.365.286-.552.066-.138.126-.278.185-.42.101-.241.197-.485.283-.732.05-.143.09-.29.135-.435.02-.061.044-.12.063-.181.043-.136.081-.274.12-.41.062-.216.123-.432.174-.651.024-.101.044-.204.065-.306.031-.149.061-.297.084-.447.016-.102.031-.204.044-.306.022-.17.042-.341.059-.512a11.632 11.632 0 0 0 .036-.916c.003-.21-.001-.421-.014-.63a8.579 8.579 0 0 0-.034-.478 9.633 9.633 0 0 0-.147-1.036c-.012-.07-.03-.138-.043-.207-.042-.226-.085-.451-.142-.673-.043-.168-.092-.335-.143-.5-.085-.278-.178-.552-.277-.825a11.558 11.558 0 0 0-.822-1.8 10.936 10.936 0 0 0-1.318-1.982 10.258 10.258 0 0 0-1.183-1.248 11.696 11.696 0 0 0-.735-.645 11.122 11.122 0 0 0-.751-.579 10.132 10.132 0 0 0-.79-.54 9.568 9.568 0 0 0-.917-.53 9.908 9.908 0 0 0-.804-.374c-.033-.014-.065-.028-.097-.04-.316-.129-.638-.24-.965-.34a10.53 10.53 0 0 0-.301-.084 10.904 10.904 0 0 0-1.973-.363c-.141-.013-.282-.022-.422-.03-.164-.01-.329-.02-.494-.022a10.301 10.301 0 0 0-.517.005 10.824 10.824 0 0 0-.551.025 9.953 9.953 0 0 0-1.192.166c-.206.04-.411.086-.616.138a10.97 10.97 0 0 0-.609.167 10.627 10.627 0 0 0-.91.318c-.128.05-.255.1-.38.155-.222.098-.441.2-.658.31a9.19 9.19 0 0 0-.484.252 10 10 0 0 0-.841.507c-.204.134-.404.272-.6.416-.148.108-.295.22-.44.333-.185.146-.368.295-.546.45-.2.173-.392.353-.582.537-.153.148-.305.298-.453.45-.155.16-.306.322-.454.488a10.454 10.454 0 0 0-.665.824c-.192.258-.375.523-.548.796a11.292 11.292 0 0 0-.432.762 10.82 10.82 0 0 0-.517 1.088 11.31 11.31 0 0 0-.5 1.442c-.072.26-.138.526-.193.792-.04.192-.074.386-.106.581a11.893 11.893 0 0 0-.093 1.125c-.008.185-.013.37-.011.554.001.135.006.27.012.405.011.237.027.474.051.71.028.28.064.558.11.835.02.124.04.248.064.372.097.499.226.99.395 1.47.093.264.2.522.315.777.11.244.232.481.36.716.17.312.353.618.55.914.043.065.085.13.13.194.209.3.436.585.676.855.103.117.208.233.316.346.148.156.305.304.463.452.089.084.174.17.266.252.173.154.349.302.529.446.136.108.275.213.416.316.075.055.15.109.227.162.172.118.345.233.523.342.103.064.209.125.315.185.142.08.285.158.43.232.194.099.391.19.59.277.106.047.212.093.32.136.195.076.395.142.594.208.293.097.589.18.889.256.212.054.425.098.639.14.325.064.653.118.983.151.15.015.298.027.448.036.35.02.702.032 1.054.02.12-.004.24-.012.359-.02.3-.02.599-.05.896-.096.32-.05.636-.116.951-.195.218-.055.436-.117.651-.185.154-.049.306-.103.458-.158.255-.092.508-.191.756-.303.114-.052.226-.109.339-.165.16-.08.319-.164.477-.25.26-.141.518-.291.768-.455.145-.094.284-.196.425-.295.172-.122.343-.245.509-.376.108-.085.217-.168.322-.257.166-.14.328-.283.486-.432.118-.113.235-.226.349-.342.123-.128.244-.257.362-.39.107-.12.211-.243.313-.367.115-.14.228-.281.338-.425.075-.099.147-.199.22-.3.111-.153.222-.307.329-.464.095-.141.186-.283.276-.428.126-.204.247-.412.366-.622.096-.171.189-.344.279-.52.079-.152.151-.308.225-.462.095-.197.188-.396.275-.598.074-.171.144-.345.21-.52.042-.113.08-.228.119-.341.093-.269.179-.541.252-.817.05-.187.093-.377.134-.567.035-.165.07-.33.1-.497.037-.208.069-.416.095-.626.026-.213.047-.427.063-.642.012-.173.025-.346.03-.52.005-.178.008-.355.008-.533-.002-.176-.008-.353-.017-.528-.015-.287-.037-.573-.069-.858a10.565 10.565 0 0 0-.156-1.078 9.56 9.56 0 0 0-.142-.613 10.795 10.795 0 0 0-.239-.84 10.27 10.27 0 0 0-.259-.743c-.143-.376-.304-.746-.485-1.105a12.467 12.467 0 0 0-.141-.276 11.92 11.92 0 0 0-.29-.533c-.103-.177-.21-.35-.32-.522-.128-.198-.261-.392-.398-.583-.171-.239-.348-.47-.531-.699-.165-.206-.335-.41-.51-.608-.216-.242-.44-.477-.671-.704a13.65 13.65 0 0 0-.267-.255c-.236-.221-.477-.436-.723-.645-.152-.128-.306-.254-.462-.376-.216-.169-.434-.335-.658-.493-.171-.121-.343-.24-.518-.355-.206-.136-.417-.268-.629-.396-.209-.125-.418-.25-.632-.368-.239-.132-.481-.258-.727-.378-.177-.086-.354-.17-.534-.25-.146-.065-.293-.127-.441-.188a11.562 11.562 0 0 0-.683-.252 10.728 10.728 0 0 0-.7-.208c-.356-.096-.715-.18-1.078-.244a11.34 11.34 0 0 0-.635-.097c-.234-.03-.47-.058-.707-.07a11.297 11.297 0 0 0-.707-.0258z"/>
                        </svg>
                        <span className="sr-only">Share on Telegram</span>
                      </Button>
                      <Button variant="outline" size="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="h-5 w-5 text-[#4267B2]" fill="currentColor">
                          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                        </svg>
                        <span className="sr-only">Share on Facebook</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
        
        <Footer />
      </main>
    </div>
  );
}
