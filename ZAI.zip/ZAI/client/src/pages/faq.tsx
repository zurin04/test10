import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Helmet } from "react-helmet";
import LegalHeader from "@/components/layout/legal-header";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown } from "lucide-react";
import { useState } from "react";

interface FAQItem {
  question: string;
  answer: string;
}

const faqData: FAQItem[] = [
  {
    question: "What is an airdrop?",
    answer: "A cryptocurrency airdrop is a distribution event where tokens or coins are sent directly to users' wallets for free. Airdrops are typically used by blockchain projects to distribute their tokens to a wider audience, reward early adopters, or increase community engagement."
  },
  {
    question: "How do I participate in airdrops?",
    answer: "To participate in airdrops: 1) Create an account on our platform, 2) Connect your cryptocurrency wallet, 3) Browse available airdrops, 4) Follow the specific requirements for each airdrop (which may include social media tasks, holding certain tokens, or interacting with smart contracts), 5) Complete the verification process as specified by each project."
  },
  {
    question: "Is it safe to connect my wallet?",
    answer: "We use Sign-In with Ethereum (SIWE) for secure wallet authentication. We never ask for your private keys or seed phrases. Only connect wallets you trust and always verify you're on the correct website. Be cautious of phishing attempts and only interact with verified projects."
  },
  {
    question: "Are there any fees to use AirdropVerse?",
    answer: "Using AirdropVerse is free for regular users. We don't charge fees for browsing airdrops, creating accounts, or participating in most activities. Some features like becoming a creator may have associated costs. Always check the specific requirements for each airdrop as some may require gas fees for blockchain transactions."
  },
  {
    question: "How do I know if an airdrop is legitimate?",
    answer: "While we curate airdrops to the best of our ability, always do your own research: 1) Check the project's official website and social media, 2) Verify the smart contract address, 3) Look for red flags like requesting private keys or upfront payments, 4) Read community feedback and reviews, 5) Be cautious of projects promising unrealistic returns."
  },
  {
    question: "What wallets are supported?",
    answer: "We support Ethereum-compatible wallets including MetaMask, WalletConnect-compatible wallets, Coinbase Wallet, and other Web3 wallets. Make sure your wallet supports the networks required by specific airdrops (Ethereum, Polygon, Arbitrum, etc.)."
  },
  {
    question: "How do I become a creator?",
    answer: "To become a creator and post airdrops: 1) Create an account, 2) Apply for creator status through your profile page, 3) Complete the verification process which may include payment verification, 4) Once approved, you can submit airdrop listings for review and publication."
  },
  {
    question: "Why haven't I received my airdrop tokens?",
    answer: "Token distribution timing varies by project. Some airdrops are instant, others may take weeks or months. Factors affecting distribution include: project timeline, snapshot requirements, manual verification processes, and network congestion. Always check the project's official announcements for updates."
  },
  {
    question: "Can I participate in multiple airdrops?",
    answer: "Yes, you can participate in as many airdrops as you qualify for. However, each project has its own eligibility criteria and rules. Some may require holding specific tokens, having transaction history, or meeting other requirements. Using multiple accounts to game rewards is prohibited."
  },
  {
    question: "What are the tax implications of receiving airdrops?",
    answer: "Airdrop taxation varies by jurisdiction. In many countries, receiving airdrops may be considered taxable income at fair market value when received. Additionally, selling airdropped tokens may trigger capital gains tax. Consult with a tax professional familiar with cryptocurrency regulations in your area."
  },
  {
    question: "How do I report a suspicious airdrop?",
    answer: "If you encounter a suspicious or fraudulent airdrop listing, please contact our support team immediately with details. We take security seriously and investigate all reports. You can reach us through the contact form or email us directly."
  },
  {
    question: "Can I cancel my participation in an airdrop?",
    answer: "Once you've submitted information for an airdrop, you typically cannot cancel your participation as the data is often recorded on the blockchain. However, you can update your preferences to stop receiving notifications about future airdrops from your account settings."
  }
];

export default function FAQ() {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  return (
    <>
      <Helmet>
        <title>FAQ - Frequently Asked Questions | AirdropVerse</title>
        <meta name="description" content="Find answers to common questions about cryptocurrency airdrops, wallet connections, and using the AirdropVerse platform." />
      </Helmet>
      
      <LegalHeader />
      
      <div className="container py-10 max-w-4xl mx-auto">
        <Card className="border-gray-800 shadow-lg">
          <CardHeader className="border-b border-gray-800">
            <CardTitle className="text-2xl font-bold">Frequently Asked Questions</CardTitle>
            <p className="text-gray-400">Find answers to common questions about cryptocurrency airdrops and our platform.</p>
          </CardHeader>
          
          <CardContent className="pt-6">
            <div className="space-y-4">
              {faqData.map((item, index) => (
                <Collapsible key={index} open={openItems.includes(index)} onOpenChange={() => toggleItem(index)}>
                  <CollapsibleTrigger className="flex w-full items-center justify-between rounded-lg border border-gray-700 bg-gray-800/50 p-4 text-left transition-colors hover:bg-gray-800">
                    <span className="font-medium text-white">{item.question}</span>
                    <ChevronDown className={`h-4 w-4 transition-transform ${openItems.includes(index) ? 'rotate-180' : ''}`} />
                  </CollapsibleTrigger>
                  <CollapsibleContent className="overflow-hidden data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
                    <div className="border-x border-b border-gray-700 bg-gray-900/50 p-4">
                      <p className="text-gray-300 leading-relaxed">{item.answer}</p>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              ))}
            </div>
            
            <div className="mt-8 p-4 bg-gradient-to-br from-blue-900/20 to-purple-900/20 border border-blue-800/30 rounded-lg">
              <h3 className="text-lg font-semibold text-white mb-2">Still have questions?</h3>
              <p className="text-gray-300 mb-3">
                If you can't find the answer you're looking for, don't hesitate to reach out to our support team.
              </p>
              <a 
                href="mailto:support@airdropverse.com" 
                className="inline-block bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-md hover:from-blue-700 hover:to-purple-700 transition-all duration-300"
              >
                Contact Support
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}