import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Helmet } from "react-helmet";
import LegalHeader from "@/components/layout/legal-header";
import { Badge } from "@/components/ui/badge";

export default function CommunityRules() {
  return (
    <>
      <Helmet>
        <title>Community Rules | AirdropVerse</title>
        <meta name="description" content="Guidelines and rules for participating in the AirdropVerse community, chat, and platform interactions." />
      </Helmet>
      
      <LegalHeader />
      
      <div className="container py-10 max-w-4xl mx-auto">
        <Card className="border-gray-800 shadow-lg">
          <CardHeader className="border-b border-gray-800">
            <CardTitle className="text-2xl font-bold">Community Rules</CardTitle>
            <p className="text-gray-400">Guidelines for maintaining a respectful and productive community environment.</p>
          </CardHeader>
          
          <CardContent className="pt-6 prose prose-invert max-w-none">
            <p className="text-sm text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>
            
            <div className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 border border-blue-800/30 rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold text-white mb-2">Welcome to AirdropVerse Community!</h3>
              <p className="text-gray-300">
                Our community thrives on mutual respect, knowledge sharing, and collaborative learning. 
                These rules help ensure everyone has a positive experience while exploring the world of cryptocurrency airdrops.
              </p>
            </div>

            <h2>1. Respect and Civility</h2>
            <ul>
              <li><strong>Be respectful:</strong> Treat all community members with courtesy and respect, regardless of their experience level</li>
              <li><strong>No harassment:</strong> Harassment, bullying, or discrimination based on race, gender, religion, nationality, or any other characteristic is strictly prohibited</li>
              <li><strong>Professional language:</strong> Keep discussions professional and avoid offensive language, personal attacks, or inflammatory content</li>
              <li><strong>Constructive feedback:</strong> When providing criticism, keep it constructive and focused on ideas rather than individuals</li>
            </ul>

            <h2>2. Content Guidelines</h2>
            <ul>
              <li><strong>Stay on topic:</strong> Keep discussions relevant to cryptocurrency, airdrops, and blockchain technology</li>
              <li><strong>No spam:</strong> Avoid repetitive posts, excessive self-promotion, or irrelevant content</li>
              <li><strong>Quality contributions:</strong> Share valuable insights, ask thoughtful questions, and contribute meaningfully to discussions</li>
              <li><strong>No financial advice:</strong> Do not provide specific financial or investment advice; share educational content and personal opinions only</li>
            </ul>

            <h2>3. Security and Safety</h2>
            <ul>
              <li><strong>Never share private keys:</strong> Never request or share private keys, seed phrases, or sensitive wallet information</li>
              <li><strong>Verify information:</strong> Always verify airdrop information from official sources before participating</li>
              <li><strong>Report suspicious activity:</strong> Report any suspicious airdrops, scams, or fraudulent behavior immediately</li>
              <li><strong>No phishing attempts:</strong> Do not share suspicious links or attempt to collect users' private information</li>
            </ul>

            <h2>4. Chat Guidelines</h2>
            <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 mb-4">
              <h3 className="text-white font-medium mb-2">Global Chat Rules</h3>
              <ul className="space-y-2">
                <li>• Keep messages relevant and constructive</li>
                <li>• No excessive caps lock or repeated messages</li>
                <li>• Respect others' opinions and engage in healthy debates</li>
                <li>• Use appropriate language suitable for all audiences</li>
                <li>• No sharing of referral links without context or permission</li>
              </ul>
            </div>

            <h2>5. Airdrop Submissions</h2>
            <ul>
              <li><strong>Accurate information:</strong> Provide accurate and up-to-date information when submitting airdrops</li>
              <li><strong>Legitimate projects only:</strong> Only submit airdrops from legitimate, verified projects</li>
              <li><strong>Complete descriptions:</strong> Include comprehensive details about requirements, eligibility, and deadlines</li>
              <li><strong>No duplicate submissions:</strong> Check for existing listings before submitting new airdrops</li>
            </ul>

            <h2>6. Account Integrity</h2>
            <ul>
              <li><strong>One account per person:</strong> Maintain only one account per individual</li>
              <li><strong>Authentic information:</strong> Provide genuine information in your profile and submissions</li>
              <li><strong>No account selling:</strong> Accounts cannot be sold, transferred, or shared with others</li>
              <li><strong>Secure your account:</strong> Use strong passwords and enable security features</li>
            </ul>

            <h2>7. Prohibited Activities</h2>
            <div className="bg-red-900/20 border border-red-800/30 rounded-lg p-4 mb-4">
              <h3 className="text-red-400 font-medium mb-2">The following activities are strictly prohibited:</h3>
              <ul className="space-y-1">
                <li>• Promoting scams, Ponzi schemes, or fraudulent projects</li>
                <li>• Sharing malicious links or attempting to hack user accounts</li>
                <li>• Creating multiple accounts to abuse airdrop rewards</li>
                <li>• Manipulating voting or engagement systems</li>
                <li>• Impersonating staff members, influencers, or project teams</li>
                <li>• Distributing copyrighted content without permission</li>
                <li>• Engaging in any illegal activities</li>
              </ul>
            </div>

            <h2>8. Moderation and Enforcement</h2>
            <ul>
              <li><strong>Admin authority:</strong> <Badge className="bg-red-600 hover:bg-red-700">ADMIN</Badge> and <Badge className="bg-amber-600 hover:bg-amber-700">CREATOR</Badge> team members have the authority to moderate content and enforce rules</li>
              <li><strong>Warning system:</strong> First violations typically result in warnings; repeated violations may lead to temporary or permanent bans</li>
              <li><strong>Appeal process:</strong> Users can appeal moderation decisions by contacting support</li>
              <li><strong>Content removal:</strong> Violating content will be removed without prior notice</li>
            </ul>

            <h2>9. Reporting Violations</h2>
            <p>Help us maintain a safe community by reporting violations:</p>
            <ul>
              <li><strong>In chat:</strong> Contact online moderators or administrators directly</li>
              <li><strong>Via email:</strong> Send detailed reports to support@airdropverse.com</li>
              <li><strong>Include evidence:</strong> Provide screenshots or specific examples when reporting</li>
              <li><strong>Be specific:</strong> Clearly describe the violation and its impact</li>
            </ul>

            <h2>10. Consequences for Violations</h2>
            <div className="space-y-4">
              <div className="border border-yellow-800/30 bg-yellow-900/20 rounded-lg p-3">
                <h4 className="text-yellow-400 font-medium">Minor Violations</h4>
                <p className="text-gray-300 text-sm">Verbal warning, content removal, temporary chat restrictions</p>
              </div>
              <div className="border border-orange-800/30 bg-orange-900/20 rounded-lg p-3">
                <h4 className="text-orange-400 font-medium">Moderate Violations</h4>
                <p className="text-gray-300 text-sm">Temporary account suspension, loss of privileges, formal warning</p>
              </div>
              <div className="border border-red-800/30 bg-red-900/20 rounded-lg p-3">
                <h4 className="text-red-400 font-medium">Severe Violations</h4>
                <p className="text-gray-300 text-sm">Permanent account ban, legal action if applicable, IP restrictions</p>
              </div>
            </div>

            <h2>11. Updates to Community Rules</h2>
            <p>
              These community rules may be updated periodically to reflect platform changes and community needs. 
              Continued use of the platform constitutes acceptance of any rule modifications. 
              Major changes will be announced to the community.
            </p>

            <div className="mt-8 p-4 bg-gradient-to-br from-green-900/20 to-blue-900/20 border border-green-800/30 rounded-lg">
              <h3 className="text-lg font-semibold text-white mb-2">Questions or Concerns?</h3>
              <p className="text-gray-300 mb-3">
                If you have questions about these rules or need clarification on community guidelines, our support team is here to help.
              </p>
              <a 
                href="mailto:support@airdropverse.com" 
                className="inline-block bg-gradient-to-r from-green-600 to-blue-600 text-white px-4 py-2 rounded-md hover:from-green-700 hover:to-blue-700 transition-all duration-300"
              >
                Contact Support
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}