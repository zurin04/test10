import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import SidebarLayout from "@/components/layout/sidebar-layout";
import { Link } from "wouter";
import Footer from "@/components/layout/footer";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { useProcessedContent } from "@/utils/code-block-processor";
import type { Airdrops } from "@shared/schema";

export default function AnnouncementsPage() {
  const [filter, setFilter] = useState<'all' | 'announcement'>('all');
  
  const { data: announcements = [], isLoading, error } = useQuery<Airdrops[]>({
    queryKey: ['/api/airdrops/announcements'],
  });

  const filteredAnnouncements = announcements.filter(announcement => {
    if (filter === 'all') return true;
    return announcement.post_type === filter;
  });

  if (isLoading) {
    return (
      <SidebarLayout title="News & Announcements">
        <main className="flex-1 p-6 md:p-10">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold gradient-text">News & Announcements</h1>
              <p className="text-muted-foreground mt-2">
                Stay updated with the latest news, announcements, and platform updates.
              </p>
            </div>
            
            <div className="flex items-center justify-center min-h-[400px]">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading announcements...</p>
              </div>
            </div>
          </div>
          
          <Footer />
        </main>
      </SidebarLayout>
    );
  }

  if (error) {
    return (
      <SidebarLayout title="News & Announcements">
        <main className="flex-1 p-6 md:p-10">
          <div className="max-w-4xl mx-auto">
            <div className="text-center py-20">
              <h2 className="text-2xl font-bold text-destructive mb-4">Error Loading Announcements</h2>
              <p className="text-muted-foreground">Unable to load announcements. Please try again later.</p>
            </div>
          </div>
          
          <Footer />
        </main>
      </SidebarLayout>
    );
  }

  return (
    <SidebarLayout title="News & Announcements">
      <main className="flex-1 p-6 md:p-10">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold gradient-text">News & Announcements</h1>
            <p className="text-muted-foreground mt-2">
              Stay updated with the latest news, announcements, and platform updates.
            </p>
          </div>
          
          {/* Filter Buttons */}
          <div className="mb-8 flex flex-wrap gap-3">
            <Button 
              variant={filter === 'all' ? 'default' : 'outline'}
              onClick={() => setFilter('all')}
              className="text-sm"
            >
              All ({announcements.length})
            </Button>
            <Button 
              variant={filter === 'announcement' ? 'default' : 'outline'}
              onClick={() => setFilter('announcement')}
              className="text-sm"
            >
              Announcements ({announcements.filter(a => a.post_type === 'announcement').length})
            </Button>

          </div>

          {filteredAnnouncements.length === 0 ? (
            <div className="text-center py-20">
              <h2 className="text-2xl font-bold mb-4">No {filter === 'all' ? '' : filter} announcements yet</h2>
              <p className="text-muted-foreground">
                {filter === 'all' 
                  ? "Check back later for updates and announcements."
                  : `No ${filter} posts found. Try viewing all announcements.`
                }
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {filteredAnnouncements.map((announcement) => (
                <AnnouncementCard key={announcement.id} announcement={announcement} />
              ))}
            </div>
          )}
        </div>
        
        <Footer />
      </main>
    </SidebarLayout>
  );
}

function AnnouncementCard({ announcement }: { announcement: Airdrops }) {
  const processedContent = useProcessedContent(announcement.description || '');

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'announcement':
        return 'Announcement';
      default:
        return 'Post';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'announcement':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow duration-200">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <Badge className={getTypeColor(announcement.post_type || '')}>
                {getTypeLabel(announcement.post_type || '')}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {formatDistanceToNow(new Date(announcement.created_at), { addSuffix: true })}
              </span>
            </div>
            
            <Link href={`/airdrop/${announcement.id}`}>
              <h3 className="text-xl font-semibold mb-2 hover:text-primary cursor-pointer transition-colors">
                {announcement.title}
              </h3>
            </Link>
            
            <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
              {announcement.description}
            </p>
            
            <div className="prose prose-sm max-w-none dark:prose-invert mb-4 line-clamp-4">
              <div dangerouslySetInnerHTML={{ __html: processedContent }} />
            </div>
          </div>
          
          {announcement.image_url && (
            <div className="ml-4 flex-shrink-0">
              <img 
                src={announcement.image_url} 
                alt={announcement.title}
                className="w-20 h-20 object-cover rounded-lg"
              />
            </div>
          )}
        </div>
        
        <div className="flex items-center justify-between pt-4 border-t">
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>By {announcement.posted_by}</span>
            {announcement.views > 0 && (
              <span>{announcement.views} views</span>
            )}
          </div>
          
          <Link href={`/airdrop/${announcement.id}`}>
            <Button variant="outline" size="sm">
              Read More
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}