import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Helmet } from "react-helmet";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

export default function Settings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [notifications, setNotifications] = useState({
    email: true,
    browser: true,
    airdropUpdates: true,
    communityMessages: false
  });
  const [privacy, setPrivacy] = useState({
    profileVisible: true,
    showActivity: false,
    allowMessages: true
  });

  const handleSaveNotifications = () => {
    // In a real implementation, this would save to the backend
    toast({
      title: "Settings Saved",
      description: "Your notification preferences have been updated.",
    });
  };

  const handleSavePrivacy = () => {
    // In a real implementation, this would save to the backend
    toast({
      title: "Privacy Settings Updated",
      description: "Your privacy preferences have been saved.",
    });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black text-white">
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-3xl font-bold mb-4">Settings</h1>
            <p className="text-gray-400 mb-8">Please sign in to access your settings.</p>
            <Button asChild>
              <a href="/auth">Sign In</a>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Settings | AirdropVerse</title>
        <meta name="description" content="Manage your account settings, notifications, and privacy preferences on AirdropVerse." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black text-white">
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">Settings</h1>
              <p className="text-gray-400">Manage your account preferences and platform settings.</p>
            </div>

            <div className="grid gap-6">
              {/* Account Information */}
              <Card className="border-gray-800 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    Account Information
                    <div className="flex gap-2">
                      {user.isAdmin && <Badge className="bg-red-600 hover:bg-red-700">ADMIN</Badge>}
                      {user.isCreator && <Badge className="bg-amber-600 hover:bg-amber-700">CREATOR</Badge>}
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <Label htmlFor="username">Username</Label>
                      <Input 
                        id="username" 
                        value={user.username} 
                        disabled 
                        className="bg-gray-800 border-gray-700"
                      />
                    </div>
                    <div>
                      <Label htmlFor="wallet">Wallet Address</Label>
                      <Input 
                        id="wallet" 
                        value={user.wallet_address || "Not connected"} 
                        disabled 
                        className="bg-gray-800 border-gray-700"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea 
                      id="bio" 
                      placeholder="Tell us about yourself..." 
                      value={user.bio || ""}
                      className="bg-gray-800 border-gray-700"
                      rows={3}
                    />
                  </div>
                  <div className="grid gap-4 md:grid-cols-3">
                    <div>
                      <Label htmlFor="twitter">Twitter Handle</Label>
                      <Input 
                        id="twitter" 
                        placeholder="@username" 
                        value={user.twitter_handle || ""}
                        className="bg-gray-800 border-gray-700"
                      />
                    </div>
                    <div>
                      <Label htmlFor="discord">Discord Handle</Label>
                      <Input 
                        id="discord" 
                        placeholder="username#1234" 
                        value={user.discord_handle || ""}
                        className="bg-gray-800 border-gray-700"
                      />
                    </div>
                    <div>
                      <Label htmlFor="telegram">Telegram Handle</Label>
                      <Input 
                        id="telegram" 
                        placeholder="@username" 
                        value={user.telegram_handle || ""}
                        className="bg-gray-800 border-gray-700"
                      />
                    </div>
                  </div>
                  <Button className="w-full md:w-auto">Update Profile</Button>
                </CardContent>
              </Card>

              {/* Notification Settings */}
              <Card className="border-gray-800 shadow-lg">
                <CardHeader>
                  <CardTitle>Notification Preferences</CardTitle>
                  <p className="text-gray-400 text-sm">Control how you receive updates and notifications.</p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="email-notifications">Email Notifications</Label>
                        <p className="text-sm text-gray-400">Receive updates via email</p>
                      </div>
                      <Switch
                        id="email-notifications"
                        checked={notifications.email}
                        onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, email: checked }))}
                      />
                    </div>
                    <Separator className="bg-gray-700" />
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="browser-notifications">Browser Notifications</Label>
                        <p className="text-sm text-gray-400">Show desktop notifications</p>
                      </div>
                      <Switch
                        id="browser-notifications"
                        checked={notifications.browser}
                        onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, browser: checked }))}
                      />
                    </div>
                    <Separator className="bg-gray-700" />
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="airdrop-updates">Airdrop Updates</Label>
                        <p className="text-sm text-gray-400">Get notified about new airdrops</p>
                      </div>
                      <Switch
                        id="airdrop-updates"
                        checked={notifications.airdropUpdates}
                        onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, airdropUpdates: checked }))}
                      />
                    </div>
                    <Separator className="bg-gray-700" />
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="community-messages">Community Messages</Label>
                        <p className="text-sm text-gray-400">Notifications for chat mentions</p>
                      </div>
                      <Switch
                        id="community-messages"
                        checked={notifications.communityMessages}
                        onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, communityMessages: checked }))}
                      />
                    </div>
                  </div>
                  <Button onClick={handleSaveNotifications} className="w-full md:w-auto">
                    Save Notification Settings
                  </Button>
                </CardContent>
              </Card>

              {/* Privacy Settings */}
              <Card className="border-gray-800 shadow-lg">
                <CardHeader>
                  <CardTitle>Privacy Settings</CardTitle>
                  <p className="text-gray-400 text-sm">Control your privacy and visibility preferences.</p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="profile-visible">Profile Visibility</Label>
                        <p className="text-sm text-gray-400">Make your profile visible to other users</p>
                      </div>
                      <Switch
                        id="profile-visible"
                        checked={privacy.profileVisible}
                        onCheckedChange={(checked) => setPrivacy(prev => ({ ...prev, profileVisible: checked }))}
                      />
                    </div>
                    <Separator className="bg-gray-700" />
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="show-activity">Show Activity</Label>
                        <p className="text-sm text-gray-400">Display your airdrop activity to others</p>
                      </div>
                      <Switch
                        id="show-activity"
                        checked={privacy.showActivity}
                        onCheckedChange={(checked) => setPrivacy(prev => ({ ...prev, showActivity: checked }))}
                      />
                    </div>
                    <Separator className="bg-gray-700" />
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="allow-messages">Allow Messages</Label>
                        <p className="text-sm text-gray-400">Allow other users to message you</p>
                      </div>
                      <Switch
                        id="allow-messages"
                        checked={privacy.allowMessages}
                        onCheckedChange={(checked) => setPrivacy(prev => ({ ...prev, allowMessages: checked }))}
                      />
                    </div>
                  </div>
                  <Button onClick={handleSavePrivacy} className="w-full md:w-auto">
                    Save Privacy Settings
                  </Button>
                </CardContent>
              </Card>

              {/* Security Settings */}
              <Card className="border-gray-800 shadow-lg">
                <CardHeader>
                  <CardTitle>Security</CardTitle>
                  <p className="text-gray-400 text-sm">Manage your account security settings.</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium text-white mb-2">Password</h3>
                      <p className="text-sm text-gray-400 mb-3">Change your account password</p>
                      <Button variant="outline" className="border-gray-700">
                        Change Password
                      </Button>
                    </div>
                    <Separator className="bg-gray-700" />
                    <div>
                      <h3 className="font-medium text-white mb-2">Wallet Connection</h3>
                      <p className="text-sm text-gray-400 mb-3">
                        {user.wallet_address ? "Wallet connected" : "No wallet connected"}
                      </p>
                      <Button variant="outline" className="border-gray-700">
                        {user.wallet_address ? "Disconnect Wallet" : "Connect Wallet"}
                      </Button>
                    </div>
                    <Separator className="bg-gray-700" />
                    <div>
                      <h3 className="font-medium text-white mb-2">Account Data</h3>
                      <p className="text-sm text-gray-400 mb-3">Download or delete your account data</p>
                      <div className="flex gap-2">
                        <Button variant="outline" className="border-gray-700">
                          Download Data
                        </Button>
                        <Button variant="destructive">
                          Delete Account
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}