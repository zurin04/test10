import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { X, ChevronRight, Megaphone } from "lucide-react";
import { useState } from "react";
import type { Airdrops } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";

export default function NewsTicker() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const { data: news, isLoading } = useQuery<Airdrops[]>({
    queryKey: ['/api/airdrops/banner'],
    queryFn: async () => {
      const res = await fetch('/api/airdrops/banner');
      if (!res.ok) {
        throw new Error('Failed to fetch news');
      }
      const data = await res.json();
      console.log('Banner data fetched:', data); // Debug log
      return Array.isArray(data) ? data : [];
    },
    refetchInterval: 5000, // Refetch every 5 seconds for immediate updates
  });

  // Always show when there are banner posts - no hiding functionality
  if (isLoading || !news || news.length === 0) {
    return null;
  }

  const currentNews = news[currentIndex];

  const nextNews = () => {
    setCurrentIndex((prev) => (prev + 1) % news.length);
  };

  const previousNews = () => {
    setCurrentIndex((prev) => (prev - 1 + news.length) % news.length);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: "auto", opacity: 1 }}
        exit={{ height: 0, opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 text-white shadow-lg relative overflow-hidden"
      >
        {/* Animated background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent animate-pulse"></div>
        </div>
        
        <div className="relative z-10 flex items-center justify-between px-4 py-3 md:px-6">
          {/* Left section - Icon and "BREAKING" badge */}
          <div className="flex items-center gap-3 flex-shrink-0">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-white/20 rounded-full">
                <Megaphone className="h-4 w-4 text-white animate-pulse" />
              </div>
              <Badge variant="secondary" className="bg-white/20 text-white border-white/30 text-xs font-bold">
                NEWS
              </Badge>
            </div>
          </div>

          {/* Center section - News content */}
          <div className="flex-1 mx-4 min-w-0">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ x: 50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -50, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="flex items-center justify-center gap-2"
              >
                <Link to={`/airdrop/${currentNews.id}`}>
                  <div className="text-center cursor-pointer hover:text-orange-200 transition-colors">
                    <h3 className="font-bold text-sm md:text-base line-clamp-1">
                      {currentNews.title}
                    </h3>
                    {currentNews.description && (
                      <p className="text-xs opacity-90 line-clamp-1 hidden md:block">
                        {currentNews.description.replace(/<[^>]*>/g, '').substring(0, 100)}...
                      </p>
                    )}
                  </div>
                </Link>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Right section - Controls */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {/* Navigation buttons for multiple news items */}
            {news.length > 1 && (
              <div className="flex items-center gap-1">
                <button
                  onClick={previousNews}
                  className="p-1 hover:bg-white/20 rounded transition-colors"
                  aria-label="Previous news"
                >
                  <ChevronRight className="h-3 w-3 rotate-180" />
                </button>
                <span className="text-xs px-2">
                  {currentIndex + 1}/{news.length}
                </span>
                <button
                  onClick={nextNews}
                  className="p-1 hover:bg-white/20 rounded transition-colors"
                  aria-label="Next news"
                >
                  <ChevronRight className="h-3 w-3" />
                </button>
              </div>
            )}
            
            {/* View All News Button */}
            <Link to="/announcements">
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-white hover:bg-white/20 text-xs px-2 py-1 h-auto"
              >
                View All
              </Button>
            </Link>


          </div>
        </div>

        {/* Progress bar for auto-rotation */}
        {news.length > 1 && (
          <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-white/30">
            <motion.div
              className="h-full bg-white"
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
              onAnimationComplete={() => {
                nextNews();
              }}
            />
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}