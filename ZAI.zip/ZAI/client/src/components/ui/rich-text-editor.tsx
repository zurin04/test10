import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { 
  Bold, 
  Italic, 
  Link, 
  List, 
  ListOrdered, 
  Heading1, 
  Heading2, 
  Heading3,
  Code,
  Copy
} from "lucide-react";

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  label?: string;
}

export function RichTextEditor({ value, onChange, placeholder = "Start writing...", label }: RichTextEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const [isEditorFocused, setIsEditorFocused] = useState(false);

  useEffect(() => {
    if (editorRef.current && value !== editorRef.current.innerHTML) {
      editorRef.current.innerHTML = value;
    }
  }, [value]);

  const handleInput = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    if (editorRef.current) {
      editorRef.current.focus();
      onChange(editorRef.current.innerHTML);
    }
  };

  const insertHeading = (level: number) => {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const selectedText = range.toString();
      const headingElement = document.createElement(`h${level}`);
      headingElement.className = level === 1 ? "text-2xl font-bold mb-4" : 
                                 level === 2 ? "text-xl font-semibold mb-3" : 
                                 "text-lg font-medium mb-2";
      
      // If there's selected text, use it as the heading content
      if (selectedText) {
        headingElement.textContent = selectedText;
        try {
          range.deleteContents();
          range.insertNode(headingElement);
          // Place cursor at the end of the heading
          range.setStartAfter(headingElement);
          range.setEndAfter(headingElement);
          selection.removeAllRanges();
          selection.addRange(range);
        } catch (e) {
          console.error('Error inserting heading:', e);
        }
      } else {
        // If no text is selected, insert an empty heading and place cursor inside
        headingElement.textContent = 'Heading ' + level;
        try {
          range.insertNode(headingElement);
          // Select the text inside the heading so user can type over it
          range.setStart(headingElement.firstChild!, 0);
          range.setEnd(headingElement.firstChild!, headingElement.textContent.length);
          selection.removeAllRanges();
          selection.addRange(range);
        } catch (e) {
          console.error('Error inserting heading:', e);
        }
      }
    } else {
      // Fallback: use document.execCommand
      execCommand('formatBlock', `h${level}`);
    }
    
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const insertLink = () => {
    const url = prompt('Enter the URL:');
    if (url) {
      execCommand('createLink', url);
    }
  };

  const insertCodeBlock = () => {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const selectedText = range.toString();
      
      const codeBlockContainer = document.createElement('div');
      codeBlockContainer.className = 'code-block-container my-4 relative';
      
      const codeBlock = document.createElement('pre');
      codeBlock.className = 'bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto font-mono text-sm';
      
      const codeElement = document.createElement('code');
      codeElement.textContent = selectedText || 'Your code here...';
      codeBlock.appendChild(codeElement);
      
      const copyButton = document.createElement('button');
      copyButton.className = 'copy-code-btn absolute top-2 right-2 bg-gray-700 hover:bg-gray-600 text-white p-2 rounded text-xs opacity-75 hover:opacity-100 transition-opacity';
      copyButton.innerHTML = '📋 Copy';
      copyButton.onclick = (e) => {
        e.preventDefault();
        navigator.clipboard.writeText(codeElement.textContent || '');
        copyButton.innerHTML = '✓ Copied!';
        setTimeout(() => {
          copyButton.innerHTML = '📋 Copy';
        }, 2000);
      };
      
      codeBlockContainer.appendChild(codeBlock);
      codeBlockContainer.appendChild(copyButton);
      
      try {
        range.deleteContents();
        range.insertNode(codeBlockContainer);
        range.setStartAfter(codeBlockContainer);
        range.setEndAfter(codeBlockContainer);
        selection.removeAllRanges();
        selection.addRange(range);
      } catch (e) {
        console.error('Error inserting code block:', e);
      }
    }
    
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const toolbarButtons = [
    { icon: Heading1, onClick: () => insertHeading(1), title: "Heading 1" },
    { icon: Heading2, onClick: () => insertHeading(2), title: "Heading 2" },
    { icon: Heading3, onClick: () => insertHeading(3), title: "Heading 3" },
    { icon: Bold, onClick: () => execCommand('bold'), title: "Bold" },
    { icon: Italic, onClick: () => execCommand('italic'), title: "Italic" },
    { icon: Link, onClick: insertLink, title: "Insert Link" },
    { icon: Code, onClick: insertCodeBlock, title: "Code Block" },
    { icon: List, onClick: () => execCommand('insertUnorderedList'), title: "Bullet List" },
    { icon: ListOrdered, onClick: () => execCommand('insertOrderedList'), title: "Numbered List" },
  ];

  return (
    <div className="space-y-2">
      {label && <Label>{label}</Label>}
      <div className="border rounded-md">
        {/* Toolbar */}
        <div className="border-b p-2 flex flex-wrap gap-1">
          {toolbarButtons.map((button, index) => (
            <Button
              key={index}
              type="button"
              variant="ghost"
              size="sm"
              onClick={button.onClick}
              title={button.title}
              className="h-8 w-8 p-0"
            >
              <button.icon className="h-4 w-4" />
            </Button>
          ))}
        </div>
        
        {/* Editor */}
        <div
          ref={editorRef}
          contentEditable
          className={`min-h-[200px] p-4 focus:outline-none prose prose-sm max-w-none bg-background text-foreground
            prose-headings:text-foreground prose-p:text-foreground prose-strong:text-foreground 
            prose-em:text-foreground prose-a:text-primary prose-ul:text-foreground prose-ol:text-foreground
            prose-li:text-foreground prose-code:text-foreground prose-pre:bg-gray-900 prose-pre:text-gray-100
            ${!value && !isEditorFocused ? 'text-muted-foreground' : 'text-foreground'}
          `}
          onInput={handleInput}
          onFocus={() => setIsEditorFocused(true)}
          onBlur={() => setIsEditorFocused(false)}
          dangerouslySetInnerHTML={!value && !isEditorFocused ? { __html: `<p class="text-muted-foreground">${placeholder}</p>` } : undefined}
          style={{
            minHeight: '200px',
            maxHeight: '400px',
            overflowY: 'auto',
            color: 'hsl(var(--foreground))'
          }}
        />
      </div>
    </div>
  );
}