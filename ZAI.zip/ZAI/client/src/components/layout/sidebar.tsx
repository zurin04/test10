import { useLocation, Link } from "wouter";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Category, SiteSettings } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useMobile } from "@/hooks/use-mobile";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import NotificationSystem from "@/components/ui/notification-system";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import LanguageSelector from "@/components/ui/language-selector";

export default function Sidebar() {
  const [location] = useLocation();
  const isMobile = useMobile();
  const [isOpen, setIsOpen] = useState(false);
  const [categoriesOpen, setCategoriesOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { user, logoutMutation } = useAuth();

  // Fetch categories for the navigation
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Fetch site settings for logo and site name
  const { data: siteSettings } = useQuery<SiteSettings>({
    queryKey: ["/api/site-settings"],
  });

  const isActive = (path: string) => {
    // Check if the path is exactly matching or if it's a category path and the current location is for that category
    if (location === path) return true;
    
    // For category paths, check if we're on a specific category page
    if (path.startsWith('/airdrops/category/') && location.startsWith('/airdrops/category/')) {
      const categoryId = path.split('/').pop();
      const currentCategoryId = location.split('/').pop();
      return categoryId === currentCategoryId;
    }
    
    return false;
  };

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const toggleCategories = () => {
    setCategoriesOpen(!categoriesOpen);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <aside className={`${isCollapsed && !isMobile ? 'w-16' : 'w-full md:w-64'} bg-gradient-to-b from-gray-900 to-gray-800 shadow-xl md:h-screen md:sticky md:top-0 md:overflow-y-auto transition-all duration-300 border-r border-gray-700/50`}>
      <div className="p-4 flex items-center justify-between md:justify-center border-b border-gray-700/50">
        <div className="flex items-center space-x-2">
          {siteSettings?.logo_url ? (
            <img 
              src={siteSettings.logo_url} 
              alt="Logo" 
              className="h-8 w-auto object-contain" 
            />
          ) : (
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
            </div>
          )}
          {(!isCollapsed || isMobile) && (
            <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              {siteSettings?.site_name || "AirdropHub"}
            </h1>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {!isMobile && (
            <button 
              className="hidden md:block text-gray-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-gray-700/50" 
              onClick={() => setIsCollapsed(!isCollapsed)}
              aria-label="Toggle sidebar"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 transition-transform ${isCollapsed ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
              </svg>
            </button>
          )}
          <button 
            className="md:hidden text-gray-400 hover:text-white transition-colors" 
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
      
      <nav className={`${isMobile && !isOpen ? "hidden" : "block"} p-4 ${isCollapsed && !isMobile ? 'px-2' : ''}`}>
        <ul className="space-y-1">
          {/* Navigation Section */}
          {(!isCollapsed || isMobile) && (
            <li className="mb-6">
              <h3 className="text-xs uppercase text-gray-400 font-bold mb-3 px-3 tracking-wider">Navigation</h3>
            </li>
          )}
          
          <li>
            <Link to="/" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${isActive("/") ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/25" : "text-gray-300 hover:bg-gray-700/50 hover:text-white"}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
                {(!isCollapsed || isMobile) && <span className="font-medium">Home</span>}
            </Link>
          </li>

          {/* Create Post - TOP PRIORITY for creators and admins */}
          {(user?.isCreator || user?.isAdmin) && (
            <li>
              <Link to="/create-post" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 border-2 border-blue-400/30 ${isActive("/create-post") ? "bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-lg shadow-blue-500/25 border-blue-400" : "text-blue-200 hover:bg-blue-700/20 hover:text-blue-100 hover:border-blue-400/60"}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  {(!isCollapsed || isMobile) && <span className="font-bold">✏️ CREATE POST</span>}
              </Link>
            </li>
          )}



          {/* Post Banner - Admin Only */}
          {user?.isAdmin && (
            <li>
              <Link to="/post-banner" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 border-2 border-red-400/30 ${isActive("/post-banner") ? "bg-gradient-to-r from-red-500 to-pink-600 text-white shadow-lg shadow-red-500/25 border-red-400" : "text-red-200 hover:bg-red-700/20 hover:text-red-100 hover:border-red-400/60"}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
                  </svg>
                  {(!isCollapsed || isMobile) && <span className="font-bold">🎯 POST BANNER</span>}
              </Link>
            </li>
          )}
          <li>
            <Link to="/airdrops" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${isActive("/airdrops") ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/25" : "text-gray-300 hover:bg-gray-700/50 hover:text-white"}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13l-3 3m0 0l-3-3m3 3V8m0 13a9 9 0 110-18 9 9 0 010 18z" />
                </svg>
                {(!isCollapsed || isMobile) && <span className="font-medium">All Airdrops</span>}
            </Link>
          </li>

          {/* Community Section */}
          {(!isCollapsed || isMobile) && (
            <li className="pt-6 mt-4 border-t border-gray-700/50">
              <h3 className="text-xs uppercase text-green-400 font-bold mb-3 px-3 tracking-wider">Community</h3>
            </li>
          )}
          
          <li>
            <Link to="/announcements" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${isActive("/announcements") ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/25" : "text-gray-300 hover:bg-gray-700/50 hover:text-white"}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
                </svg>
                {(!isCollapsed || isMobile) && <span className="font-medium">News & Updates</span>}
            </Link>
          </li>
          
          <li>
            <Link to="/chat" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${isActive("/chat") ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/25" : "text-gray-300 hover:bg-gray-700/50 hover:text-white"}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
                {(!isCollapsed || isMobile) && <span className="font-medium">Community Chat</span>}
            </Link>
          </li>
          
          <li>
            <Link to="/members" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${isActive("/members") ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/25" : "text-gray-300 hover:bg-gray-700/50 hover:text-white"}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
                </svg>
                {(!isCollapsed || isMobile) && <span className="font-medium">Members</span>}
            </Link>
          </li>
          
          {/* Categories Section */}
          {(!isCollapsed || isMobile) && (
            <li>
              <Collapsible
                open={categoriesOpen}
                onOpenChange={setCategoriesOpen}
                className="w-full"
              >
                <CollapsibleTrigger asChild>
                  <button className="group flex items-center space-x-3 p-3 rounded-xl w-full text-left text-gray-300 hover:bg-gray-700/50 hover:text-white transition-all duration-200">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                    </svg>
                    <span className="font-medium">Categories</span>
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className={`h-4 w-4 ml-auto transition-transform duration-200 ${categoriesOpen ? 'transform rotate-180' : ''}`} 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-1 mt-2 pl-4 ml-4 border-l border-gray-700/50">
                  {categories.map(category => (
                    <Link
                      key={category.id}
                      to={`/airdrops/category/${category.id}`}
                      className={`block p-2 rounded-lg text-sm transition-all duration-200 ${
                        isActive(`/airdrops/category/${category.id}`) 
                          ? "bg-gradient-to-r from-blue-500/50 to-purple-600/50 text-white border-l-2 border-blue-400" 
                          : "text-gray-400 hover:text-gray-300 hover:bg-gray-700/30"
                      }`}
                    >
                      <span className="font-medium">{category.name}</span>
                    </Link>
                  ))}
                  {categories.length === 0 && (
                    <div className="text-sm text-gray-500 p-2">No categories available</div>
                  )}
                </CollapsibleContent>
              </Collapsible>
            </li>
          )}



          {/* Creator links - shown only to creators and admins */}
          {(user?.isCreator || user?.isAdmin) && (
            <>
              {(!isCollapsed || isMobile) && (
                <li className="pt-6 mt-4 border-t border-gray-700/50">
                  <h3 className="text-xs uppercase text-blue-400 font-bold mb-3 px-3 tracking-wider">Creator Tools</h3>
                </li>
              )}
              <li>
                <Link to={`/creator-timeline/${user?.username}`} className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${location === `/creator-timeline/${user?.username}` ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/25" : "text-gray-300 hover:bg-gray-700/50 hover:text-white"}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    {(!isCollapsed || isMobile) && <span className="font-medium">My Timeline</span>}
                </Link>
              </li>

            </>
          )}
          
          {/* Admin links - only shown to admin users */}
          {user?.isAdmin && (
            <>
              {(!isCollapsed || isMobile) && (
                <li className="pt-6 mt-4 border-t border-gray-700/50">
                  <h3 className="text-xs uppercase text-yellow-400 font-bold mb-3 px-3 tracking-wider flex items-center">
                    <span className="mr-1">⚡</span>
                    Admin Zone
                  </h3>
                </li>
              )}
              <li>
                <Link to="/admin" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${isActive("/admin") ? "bg-gradient-to-r from-yellow-500 to-orange-600 text-white shadow-lg shadow-yellow-500/25 border border-yellow-500/30" : "text-gray-300 hover:bg-gray-700/50 hover:text-white hover:border-yellow-500/20 border border-transparent"}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    {(!isCollapsed || isMobile) && <span className="font-medium">Admin Dashboard</span>}
                </Link>
              </li>
              <li>
                <Link to="/admin/creator-applications" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${isActive("/admin/creator-applications") ? "bg-gradient-to-r from-yellow-500 to-orange-600 text-white shadow-lg shadow-yellow-500/25 border border-yellow-500/30" : "text-gray-300 hover:bg-gray-700/50 hover:text-white hover:border-yellow-500/20 border border-transparent"}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    {(!isCollapsed || isMobile) && <span className="font-medium">Creator Applications</span>}
                </Link>
              </li>
            </>
          )}
          
          {/* Account Section */}
          {(!isCollapsed || isMobile) && (
            <li className="pt-6 mt-6 border-t border-gray-700/50">
              <h3 className="text-xs uppercase text-purple-400 font-bold mb-3 px-3 tracking-wider">Account</h3>
            </li>
          )}
          
          <li>
            {user ? (
              <div className="space-y-3">
                {(!isCollapsed || isMobile) && (
                  <div className="px-3 py-2 bg-gray-800/50 rounded-lg border border-gray-700/50">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="text-sm text-gray-400">Logged in as</div>
                        <div className={`font-bold ${user.isAdmin ? 'bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent' : 'text-white'}`}>
                          {user.username}
                        </div>
                        {user.isAdmin && (
                          <span className="inline-block mt-1 text-xs bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-2 py-1 rounded-full">
                            ⚡ ADMIN
                          </span>
                        )}
                      </div>
                      <NotificationSystem />
                    </div>
                  </div>
                )}
                <Link to="/dashboard" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${isActive("/dashboard") ? "bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-lg shadow-blue-500/25" : "text-gray-300 hover:bg-gray-700/50 hover:text-white"}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                  {(!isCollapsed || isMobile) && <span className="font-medium">My Dashboard</span>}
                </Link>
                <Link to="/profile" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${isActive("/profile") ? "bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/25" : "text-gray-300 hover:bg-gray-700/50 hover:text-white"}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                  {(!isCollapsed || isMobile) && <span className="font-medium">My Profile</span>}
                </Link>
                {!user.wallet_address && (
                  <Link to="/change-password" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${isActive("/change-password") ? "bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/25" : "text-gray-300 hover:bg-gray-700/50 hover:text-white"}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                    </svg>
                    {(!isCollapsed || isMobile) && <span className="font-medium">Change Password</span>}
                  </Link>
                )}
                <Button 
                  variant="outline" 
                  className={`w-full justify-start bg-red-500/10 border-red-500/30 text-red-400 hover:bg-red-500/20 hover:text-red-300 hover:border-red-500/50 transition-all duration-200 ${isCollapsed && !isMobile ? 'px-3' : ''}`}
                  onClick={handleLogout}
                  disabled={logoutMutation.isPending}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                  </svg>
                  {(!isCollapsed || isMobile) && <span className="font-medium">Logout</span>}
                </Button>
              </div>
            ) : (
              <Link to="/auth" className={`group flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${isActive("/auth") ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/25" : "text-gray-300 hover:bg-gray-700/50 hover:text-white"}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                  </svg>
                  {(!isCollapsed || isMobile) && <span className="font-medium">Login / Register</span>}
              </Link>
            )}
          </li>
        </ul>
      </nav>
    </aside>
  );
}
