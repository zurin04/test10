/**
 * Processes HTML content to add copy buttons to code blocks
 */
export function processCodeBlocks(htmlContent: string): string {
  if (!htmlContent) return htmlContent;

  // Add event listeners for copy buttons after DOM update
  const addCopyListeners = () => {
    setTimeout(() => {
      const copyButtons = document.querySelectorAll('.copy-code-btn');
      copyButtons.forEach(button => {
        if (!button.hasAttribute('data-listener-added')) {
          button.setAttribute('data-listener-added', 'true');
          button.addEventListener('click', async (e) => {
            e.preventDefault();
            const codeElement = button.parentElement?.querySelector('code');
            if (codeElement) {
              try {
                await navigator.clipboard.writeText(codeElement.textContent || '');
                const originalText = button.innerHTML;
                button.innerHTML = '✓ Copied!';
                setTimeout(() => {
                  button.innerHTML = originalText;
                }, 2000);
              } catch (err) {
                console.error('Failed to copy code:', err);
              }
            }
          });
        }
      });
    }, 100);
  };

  // Process the HTML to ensure code blocks have copy buttons
  let processedContent = htmlContent;

  // Find code blocks that don't already have copy buttons
  const codeBlockRegex = /<div class="code-block-container[^>]*>[\s\S]*?<\/div>/g;
  
  // If we have code blocks, ensure they have proper structure
  processedContent = processedContent.replace(codeBlockRegex, (match) => {
    if (!match.includes('copy-code-btn')) {
      // Extract the code content
      const codeMatch = match.match(/<code[^>]*>([\s\S]*?)<\/code>/);
      if (codeMatch) {
        const codeContent = codeMatch[1];
        return `<div class="code-block-container my-4 relative">
          <pre class="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto font-mono text-sm">
            <code>${codeContent}</code>
          </pre>
          <button class="copy-code-btn absolute top-2 right-2 bg-gray-700 hover:bg-gray-600 text-white p-2 rounded text-xs opacity-75 hover:opacity-100 transition-opacity">📋 Copy</button>
        </div>`;
      }
    }
    return match;
  });

  // Add listeners after processing
  addCopyListeners();

  return processedContent;
}

/**
 * React hook to process HTML content with code block copy functionality
 */
export function useProcessedContent(htmlContent: string) {
  return processCodeBlocks(htmlContent);
}